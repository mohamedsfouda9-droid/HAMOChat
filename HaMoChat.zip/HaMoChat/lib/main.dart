import 'package:flutter/material.dart';

const navy = Color(0xFF102A56);
const navyDeep = Color(0xFF081A36);
const blue = Color(0xFF2F6FED);

void main() => runApp(const HaMoChatApp());

class HaMoChatApp extends StatelessWidget {
  const HaMoChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HaMo شات',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: navy, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F7FC),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      width: double.infinity,
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [navy, navyDeep])),
      child: SafeArea(child: Padding(
        padding: const EdgeInsets.all(26),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 116, height: 116, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(34)),
            child: const Icon(Icons.chat_bubble_rounded, size: 66, color: navy)),
          const SizedBox(height: 24),
          const Text('HaMo شات', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Colors.white)),
          const SizedBox(height: 10),
          const Text('خليك قريب من الناس اللي بتحبهم', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: Color(0xFFD9E5FF))),
          const SizedBox(height: 36),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 16)),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PhoneLoginScreen())),
            child: const Text('ابدأ الآن', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          )),
          const SizedBox(height: 16),
          const Text('نسخة تجريبية للواجهة — تسجيل الدخول غير مربوط بسيرفر بعد', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFB9C9E8), fontSize: 12)),
        ]),
      )),
    ),
  );
}

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});
  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final phone = TextEditingController();
  @override
  void dispose() { phone.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تسجيل الدخول')),
    body: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 20),
      const Text('أهلاً بيك في HaMo شات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 8),
      const Text('اكتب رقم هاتفك. إرسال كود SMS الحقيقي يحتاج ربط خدمة مصادقة.'),
      const SizedBox(height: 24),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', hintText: '+20 1xxxxxxxxx', prefixIcon: Icon(Icons.phone_android))),
      const SizedBox(height: 16),
      FilledButton(onPressed: () {
        if (phone.text.trim().length < 8) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب رقم هاتف صحيح للتجربة')));
          return;
        }
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ChatsScreen()));
      }, child: const Padding(padding: EdgeInsets.all(14), child: Text('متابعة للتجربة'))),
      const SizedBox(height: 10),
      const Text('تنبيه: الزر يفتح الواجهة التجريبية فقط، ولا يرسل رسالة أو كود تحقق حقيقي.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ])),
  );
}

class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key});
  static const people = [
    ('أحمد', 'تمام، هكلمك بعدين 👋', '10:42 ص', 'أ'),
    ('مريم', 'وصلت الصور؟', '9:18 ص', 'م'),
    ('شلة الصحاب', 'كريم: نشوفكم بكرة', 'أمس', 'ش'),
    ('محمد', 'ربنا يخليك ❤️', 'أمس', 'م'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('HaMo شات'), actions: [IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())), icon: const Icon(Icons.settings_outlined))]),
    body: ListView(padding: const EdgeInsets.all(12), children: [
      TextField(decoration: InputDecoration(hintText: 'ابحث عن محادثة', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none))),
      const SizedBox(height: 10),
      for (final p in people) Card(color: Colors.white, elevation: 0, child: ListTile(
        leading: CircleAvatar(backgroundColor: const Color(0xFFDCE7FF), foregroundColor: navy, child: Text(p.$4, style: const TextStyle(fontWeight: FontWeight.bold))),
        title: Text(p.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(p.$2, maxLines: 1, overflow: TextOverflow.ellipsis),
        trailing: Text(p.$3, style: const TextStyle(fontSize: 11, color: Colors.black54)),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatRoom(name: p.$1))),
      )),
    ]),
    floatingActionButton: FloatingActionButton(backgroundColor: navy, foregroundColor: Colors.white, onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('إضافة محادثة هتتفعّل بعد ربط قاعدة البيانات'))), child: const Icon(Icons.chat)),
  );
}

class ChatRoom extends StatefulWidget {
  final String name;
  const ChatRoom({super.key, required this.name});
  @override
  State<ChatRoom> createState() => _ChatRoomState();
}
class _ChatRoomState extends State<ChatRoom> {
  final input = TextEditingController();
  final messages = <String>[];
  @override
  void dispose() { input.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.name)),
    body: Column(children: [
      Expanded(child: messages.isEmpty ? const Center(child: Text('ابدأ المحادثة برسالة تجريبية')) : ListView(padding: const EdgeInsets.all(12), children: [for (final m in messages) Align(alignment: Alignment.centerRight, child: Container(margin: const EdgeInsets.symmetric(vertical: 4), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFDCE7FF), borderRadius: BorderRadius.circular(14)), child: Text(m)))])),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'اكتب رسالة...'))), const SizedBox(width: 8), IconButton.filled(onPressed: () { final t = input.text.trim(); if (t.isNotEmpty) { setState(() => messages.add(t)); input.clear(); } }, icon: const Icon(Icons.send), style: IconButton.styleFrom(backgroundColor: navy))]))),
    ]),
  );
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('الإعدادات')), body: ListView(children: const [
    ListTile(leading: Icon(Icons.person_outline), title: Text('الحساب'), subtitle: Text('إعدادات الحساب ستتوفر بعد ربط المصادقة')),
    ListTile(leading: Icon(Icons.lock_outline), title: Text('الخصوصية'), subtitle: Text('خيارات الخصوصية قيد التطوير')),
    ListTile(leading: Icon(Icons.notifications_outlined), title: Text('الإشعارات'), subtitle: Text('الإشعارات تحتاج إعداد خدمة خلفية')),
    ListTile(leading: Icon(Icons.info_outline), title: Text('عن التطبيق'), subtitle: Text('HaMo شات — نسخة واجهة تجريبية')),
  ]));
}
