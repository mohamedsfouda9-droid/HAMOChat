import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AppLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const AppLockScreen({super.key, required this.onUnlocked});
  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final controller = TextEditingController();
  bool loading = false;
  bool showPassword = false;
  String? error;

  Future<void> unlock() async {
    if (loading) return;
    if (!Supabase.instance.isInitialized) {
      setState(() => error = 'إعداد Supabase غير مكتمل. راجع README.md');
      return;
    }
    if (Supabase.instance.client.auth.currentSession == null) {
      setState(() => error = 'سجّل الدخول بحسابك أولًا. ربط تسجيل الدخول سيُضاف في الخطوة التالية.');
      return;
    }
    setState(() { loading = true; error = null; });
    try {
      final res = await Supabase.instance.client.functions.invoke('verify-app-passcode', body: {'password': controller.text});
      if (!mounted) return;
      if (res.status == 200 && res.data is Map && res.data['ok'] == true) {
        controller.clear(); widget.onUnlocked();
      } else {
        setState(() => error = 'كلمة المرور غير صحيحة أو تعذّر التحقق.');
      }
    } catch (_) {
      if (mounted) setState(() => error = 'تعذّر الاتصال بالخادم. راجع إعدادات Supabase.');
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.lock_rounded, size: 76, color: Color(0xFF40D9A2)),
      const SizedBox(height: 18), const Text('HaMo شات', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), const Text('أدخل كلمة المرور للمتابعة', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 28), TextField(controller: controller, obscureText: !showPassword, onSubmitted: (_) => unlock(), decoration: InputDecoration(hintText: 'كلمة المرور', filled: true, fillColor: const Color(0xFF202C33), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none), suffixIcon: IconButton(onPressed: () => setState(() => showPassword = !showPassword), icon: Icon(showPassword ? Icons.visibility_off : Icons.visibility)))),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 22), SizedBox(width: double.infinity, height: 50, child: ElevatedButton(onPressed: loading ? null : unlock, child: Text(loading ? 'جارٍ التحقق...' : 'فتح التطبيق'))),
      const SizedBox(height: 16), const Text('هذه نسخة بداية؛ يلزم إعداد تسجيل الدخول وقاعدة البيانات قبل الاستخدام الفعلي.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.white54)),
    ])))),
  );
}
