// Supabase Edge Function: verifies the shared app lock only after validating the user's session.
// Configure APP_LOCK_PASSWORD as a server-side secret. Never place it in the Flutter app.
Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return Response.json({ ok: false }, { status: 401 });

  const url = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const expected = Deno.env.get('APP_LOCK_PASSWORD');
  if (!url || !anonKey || !expected) return Response.json({ ok: false, error: 'Server not configured' }, { status: 500 });

  const userRes = await fetch(`${url}/auth/v1/user`, { headers: { apikey: anonKey, Authorization: authHeader } });
  if (!userRes.ok) return Response.json({ ok: false }, { status: 401 });

  try {
    const body = await req.json();
    if (typeof body?.password !== 'string') return Response.json({ ok: false }, { status: 400 });
    if (body.password !== expected) return Response.json({ ok: false }, { status: 401 });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }
});
